<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e($param); ?></title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">









    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">

</head>

<body>

    <div class="container-fluid" style="background: lightgray">
        <div class="container py-2  ">
            <div class="row d-flex  align-items-center">
                <div class="col-lg-6 d-flex justify-content-center">
                    <h1 class=""><?php echo e($param); ?>

                    </h1>
                </div>
                <div class="col-lg-6 d-flex">
                    <div class="row">
                        <div class="col">
                            <form class="d-flex" role="search" action="<?php echo e(route('search')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <input class="form-control me-2" type="search" name="search" placeholder="Search"
                                    aria-label="Search">
                                <button class="btn btn-primary" type="submit">Search</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-3">
        <table id="example" class="table table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>id</th>
                    <th>url</th>
                    <th>name</th>
                    <th>type</th>
                    <th>language</th>
                    
                    <th>status</th>
                    <th>runtime</th>
                    <th>averageRuntime</th>
                    <th>premiered</th>
                    <th>ended</th>
                    <th>officialSite</th>
                    <th>schedule</th>

                    <th>weight</th>
                    <th>updated</th>

                </tr>
            </thead>
            <tbody>

                <?php if(isset($result)): ?>


                    <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($rows['show']['id']); ?></td>
                            <td><a href="<?php echo e($rows['show']['url']); ?>"><?php echo e($rows['show']['url']); ?></a></td>
                            <td><?php echo e($rows['show']['name']); ?></td>
                            <td><?php echo e($rows['show']['type']); ?></td>
                            <td><?php echo e($rows['show']['language']); ?></td>
                            
                            <td><?php echo e($rows['show']['status']); ?></td>
                            <td><?php echo e($rows['show']['runtime']); ?></td>
                            <td><?php echo e($rows['show']['averageRuntime']); ?></td>
                            <td><?php echo e($rows['show']['premiered']); ?></td>

                            <td><?php echo e($rows['show']['ended']); ?></td>
                            <td><?php echo e($rows['show']['officialSite']); ?></td>
                            <td>
                                <?php echo e($rows['show']['schedule']['time']); ?>

                            </td>
                            <td><?php echo e($rows['show']['weight']); ?></td>
                            <td>
                                <p><?php echo e($rows['show']['updated']); ?></p>
                            </td>

                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

            </tbody>

        </table>
    </div>



    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                scrollX: true,
            });
        });
    </script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\tvmaze\resources\views/index.blade.php ENDPATH**/ ?>