<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>{{ $param }}</title>

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">









    {{-- ? Datatable Css Link --}}
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.12.1/css/dataTables.bootstrap5.min.css">

</head>

<body>

    <div class="container-fluid" style="background: lightgray">
        <div class="container py-2  ">
            <div class="row d-flex  align-items-center">
                <div class="col-lg-6 d-flex justify-content-center">
                    <h1 class="">{{ $param }}
                    </h1>
                </div>
                <div class="col-lg-6 d-flex">
                    <div class="row">
                        <div class="col">
                            <form class="d-flex" role="search" action="{{ route('search') }}" method="POST">
                                @csrf
                                <input class="form-control me-2" type="search" name="search" placeholder="Search"
                                    aria-label="Search">
                                <button class="btn btn-primary" type="submit">Search</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container my-3">
        <table id="example" class="table table-striped" style="width:100%">
            <thead>
                <tr>
                    <th>id</th>
                    <th>url</th>
                    <th>name</th>
                    <th>type</th>
                    <th>language</th>
                    {{-- <th>genres</th> --}}
                    <th>status</th>
                    <th>runtime</th>
                    <th>averageRuntime</th>
                    <th>premiered</th>
                    <th>ended</th>
                    <th>officialSite</th>
                    <th>schedule</th>

                    <th>weight</th>
                    <th>updated</th>

                </tr>
            </thead>
            <tbody>

                @if (isset($result))


                    @foreach ($result as $rows)
                        <tr>
                            <td>{{ $rows['show']['id'] }}</td>
                            <td><a href="{{ $rows['show']['url'] }}">{{ $rows['show']['url'] }}</a></td>
                            <td>{{ $rows['show']['name'] }}</td>
                            <td>{{ $rows['show']['type'] }}</td>
                            <td>{{ $rows['show']['language'] }}</td>
                            {{-- <td>{{ $rows['show']['genres'] }}</td> --}}
                            <td>{{ $rows['show']['status'] }}</td>
                            <td>{{ $rows['show']['runtime'] }}</td>
                            <td>{{ $rows['show']['averageRuntime'] }}</td>
                            <td>{{ $rows['show']['premiered'] }}</td>

                            <td>{{ $rows['show']['ended'] }}</td>
                            <td>{{ $rows['show']['officialSite'] }}</td>
                            <td>
                                {{ $rows['show']['schedule']['time'] }}
                            </td>
                            <td>{{ $rows['show']['weight'] }}</td>
                            <td>
                                <p>{{ $rows['show']['updated'] }}</p>
                            </td>

                        </tr>
                    @endforeach
                @endif

            </tbody>

        </table>
    </div>



    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/jquery.dataTables.min.js"></script>
    <script src="https://cdn.datatables.net/1.12.1/js/dataTables.bootstrap5.min.js"></script>

    <script>
        $(document).ready(function() {
            $('#example').DataTable({
                scrollX: true,
            });
        });
    </script>
</body>

</html>
