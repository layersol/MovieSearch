<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class MovieController extends Controller
{
    //
    public function index(){

        $response = Http::get('https://api.tvmaze.com/search/shows?q=movie'); 
        
        $result = $response->body();
        $results = json_decode($result , true);
        // echo '<pre>';
        // print_r($results);
        // echo '</pre>';

        // foreach ($results as$value) {
        //     # code...
        //     print_r($value['show']);
        // }


        // die;
        $data['result'] = $results;
        // echo '<pre>';
        // print_r($result);
        // echo '</pre>';
        // die;
            $param =  "movie";
        return view('index' , ['result' => $results])->with('param' , $param);
    }

    public function search(Request $request){
        $param = $request->post('search');

        $response = Http::get("https://api.tvmaze.com/search/shows?q=".$param.""); 
        
        $result = $response->body();
        $results = json_decode($result , true);
        // echo '<pre>';
        // print_r($results);
        // echo '</pre>';
        // die;
        $data['result'] = $results;
        // // echo '<pre>';
        // // print_r($result);
        // // echo '</pre>';
        // // die;

        return view('index' , ['result' => $results])->with('param' , $param);
        
    }
}